<?php
class Image_model extends CI_Model {

    public function insert_image($data) {
        $this->db->insert('image', $data);
        return $this->db->insert_id();
    }

    public function get_images() {
        return $this->db->get('image')->result();
    }
}
?>