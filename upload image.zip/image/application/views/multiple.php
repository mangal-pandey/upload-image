<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Multiple image </title>
</head>
<body>
    <!-- application/views/upload_form.php -->
<form method="post" action="<?= base_url('multipleupdate/update') ?>" enctype="multipart/form-data">
    <input type="file" name="userfile[]" multiple >
    <button type="submit" ></button>
</form>

</body>
</html>userfile