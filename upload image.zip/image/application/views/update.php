<html>
<head>
<title>Upload Form</title>
</head>
<body>




<form method="post" action="<?= base_url('Water/uploads') ?>" enctype="multipart/form-data">
            
            <input type="file" name="image" size="20" />
            <br /><br />
            <br><button class="btn btn-primary ml-3" name="submit" type="submit"> Submit </button>
</form>



</form>

</body>
</html>