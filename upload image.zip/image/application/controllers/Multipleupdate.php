<?php
class Multipleupdate extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->helper(array('form', 'url'));
        $this->load->model('image_model');
    }


    public function index()
    {
       
            $this->load->view('multiple');
    }

    public function update(){
       

        $config['upload_path']='./images/';
        $config['allowed_types']='gif|jpg|jpeg|png';
        $config['max_size']='1024';
        $this->load->library('upload',$config);
        

        
        $file_count=count($_FILES['userfile']['name']); 

        for ($i = 0; $i < $file_count; $i++) {

            $this->upload->initialize($config);
        
        $_FILES['f']['name'] = $_FILES['userfile']['name'][$i];
        $_FILES['f']['type'] = $_FILES['userfile']['type'][$i];
        $_FILES['f']['tmp_name'] = $_FILES['userfile']['tmp_name'][$i];
        $_FILES['f']['error'] = $_FILES['userfile']['error'][$i];
        $_FILES['f']['size'] = $_FILES['userfile']['size'][$i];

        // Perform the upload for each file
        if (!$this->upload->do_upload('f')) {
            $error = array('error' => $this->upload->display_errors());
            $this->load->view('update', $error);
        } else {
            $upload_data = $this->update->data();
           
        }
    }
  } 
}
?>
