<?php
class Update extends CI_Controller {

           

  public function upload() {
    $config['upload_path'] = './images/';
    $config['allowed_types'] = 'gif|jpg|jpeg|png';
    $config['max_size'] = 1024;

    $this->load->library('upload', $config);

    $files = $_FILES['userfile'];

    $data['upload_errors'] = array();

    foreach ($files['name'] as $key => $name) {
        $_FILES['userfile']['name'] = $files['name'][$key];
        $_FILES['userfile']['type'] = $files['type'][$key];
        $_FILES['userfile']['tmp_name'] = $files['tmp_name'][$key];
        // $_FILES['userfile']['error'] = $files['error'][$key];
        // $_FILES['userfile']['size'] = $files['size'][$key];

        if (!$this->upload->do_upload('userfile')) {
            $data['upload_errors'][] = $this->upload->display_errors();
        } else {
            $upload_data = $this->upload->data();

            $data = array(
                'file_name' => $upload_data['file_name'],
                'file_path' => 'uploads/' . $upload_data['file_name'],
                'caption' => $this->input->post('caption')
            );

            $this->photo_model->insert_image($data);
        }
    }

    if (!empty($data['upload_errors'])) {
        $this->load->view('upload_form', $data);
    } else {
        redirect('uploads');
    }
  }

};

?>