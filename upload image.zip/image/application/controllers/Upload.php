<?php

class Upload extends CI_Controller {

        public function __construct()
        {
                parent::__construct();
                $this->load->helper(array('form', 'url'));
        }

        public function index()
        {
                $this->load->view('upload_form', array('error' => ' ' ));
        }

        public function do_upload()
        {

            $this->load->library('upload');
            $config['file_name']=time();
            $config['upload_path'] = './image/';
            $config['allowed_types'] = 'gif|jpg|png';
        //     $config['max_size'] = 2000;
        //     $config['max_width'] = 1500;
        //     $config['max_height'] = 1500;
             $this->upload->initialize($config);


                if ( ! $this->upload->do_upload('userfile'))
                {
                        $error = array('error' => $this->upload->display_errors());

                        $this->load->view('upload_form', $error);
                }
                else
                {
                    $vikas=$this->upload->do_upload('image');
                    $imagedata= $this->upload->data();
                    $imagename=$imagedata['file_name'];
                }
        }
}
?>